#!/usr/bin/env bash
set -euo pipefail
PROJECT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT"
[ "$(id -u)" -eq 0 ] || { echo 'Run as root.'; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y live-build debootstrap squashfs-tools xorriso grub-pc-bin grub-efi-amd64-bin mtools dosfstools rsync wget curl ca-certificates gnupg
rm -rf config work output
mkdir -p output
lb config \
  --distribution trixie \
  --architectures amd64 \
  --archive-areas 'main contrib non-free non-free-firmware' \
  --binary-images iso-hybrid \
  --debian-installer live \
  --debian-installer-gui false \
  --bootappend-live 'boot=live components quiet splash'
cp -a config.local/* config/
lb build 2>&1 | tee output/build.log
ISO=$(find . -maxdepth 1 -type f -name '*.iso' -print -quit)
[ -n "$ISO" ] || { echo 'ERROR: ISO was not produced.'; exit 2; }
mv "$ISO" output/XLoOs-Lite-1.0-amd64.iso
sha256sum output/XLoOs-Lite-1.0-amd64.iso > output/XLoOs-Lite-1.0-amd64.iso.sha256
