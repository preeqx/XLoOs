# XLoOs Lite 1.0

Debian Trixie + XFCE, aimed at low-resource PCs.

## Profiles
- Normal: XFCE, browser, file manager, terminal, NetworkManager, Bluetooth, firmware, Calamares.
- Gaming: same lightweight base with gaming-oriented defaults; install Steam/Games after installation as needed.

## Build
This project is intended to build on an amd64 Debian/Ubuntu machine or GitHub Actions. Building an amd64 live ISO directly inside Android Termux/proot is not supported reliably.

GitHub Actions: upload this project to a GitHub repository, open Actions > Build XLoOs Lite > Run workflow, then download the ISO artifact.
