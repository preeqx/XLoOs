XLoOs Lite build configuration.
Normal and Gaming are intended as two lightweight profiles. The base image is deliberately small; gaming software should be installed after setup rather than bloating the ISO.
